#include "stack7.h"
#include <iostream>
using namespace std;
typedef int cat;
int main()
{
    int i;
    cat b;
    string str; //for deciding push or pull
    cin >> m >> n;
    stack1::id s= stack1::intialize(m);
    stack1::create(s); //creating n elements for each stack

    for(i=0;i<n;i++){
        cin >> a >>str;
        if (str=="push"){ //to check if the operation is push
             cin >> b;
             stack1::push(s,b);
        }
        else if(str=="pop"){
            stack1::pop(s) ;
        }
        else{
            cout <<"Please select either push or pull";
        }
    }
    stack1::print(s);
    stack1::destroy_stack(s); //destroy  array of elements in each stack

}
