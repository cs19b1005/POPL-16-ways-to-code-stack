                                                       README

Steps to run binaries
1.We have to run the makefile in the assignment folder using command make.
2.The makefile will execute and is able to link all files in stack0/stack1 .It will generate a binary(output) file which is moved to the bin folder.
3.We can get the binary files from the folder assignment/bin/stack0
and will be able to run against test cases.

Method0:I have created a 2d pointer to stack_id so that there will be m stacks and each stack contains a max of n elements. For the n conditions, it will execute(either push or pop) and finally delete memory used by the stack

Method1:i have created a m stack pointers each of struct stack_id contains top(top value of each stack) and an array of max n elements.
For the n conditions, it will execute(either push or pop
) and finally delete memory used by the stack.

Method2:Same as method1 but contains a class the respective definitions are mentioned in method2.Since functions are static we can use stack1::f();

Method3:In this method there are private variables that can be accessed within a class. Hence I have defined function definitions inside a class. Creation of stacks same as method2.

Method4:In this method there is a class inside a class and also the variables are private and we defined a typedef rep*id.By this i have created memory for stack id’s and destroyed them at last without memory leaks.

Method 5:Here we use constructors for initialization and destructors for deleting pointers.Same as method2 for push and pop.

Method 6:Here we declared a different class but given it as public for the main class.Same as method2 for push and pop.

Method 7:Here we use id’s(typedef stack1*id)for declaration of m stacks.Same as method2 for push and pop.

Method8:Here the functions are non-static and we declared constructors for initialization. First, we call constructor and the object created will be used for the entire program for push and pop in stack.h file.

Method9:Same as method 8 but a small difference in the declaration.

Method10:Here pure virtual functions are used and I have used an array for declaration of memory(i.e astack).
stack.h is used for declaring virtual functions.astack.h for initialization and push,pop operations.

Method11:Here we use llstack as an object for operations push and pop.

Method12:i have define an astack,lstack .astack as array implementation whereas lstack has linkedlist implementation
After all operations of push and pop .we copy the elements of array to linked list.
Method 16:Here I have used a slightly different method. Instead of using constructors in method 5, I have declared a function that is used in the initialization

Method 17:In this method I have used linked list implementation for push and pop.






