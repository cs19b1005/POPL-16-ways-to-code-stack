#include "stack4.h"
#include <iostream>
typedef int cat;
using namespace std;
int main()
{
    int i;
    cat b;
    cin >> m >> n;
    stack1::id s= stack1::intialize();
    stack1::create(s);
    string str; //for deciding push or pull
    for(i=0;i<n;i++){
        cin >> a >>str;
        if (str=="push"){ //to check if the operation is push
            cin >> b;
            stack1::push(s,b);
        }
        else if(str=="pop"){
            stack1::pop(s) ;
        }
        else{
            cout <<"Please select either push or pull";
        }
    }
    stack1::print(s);
    stack1::destroy_stack(s); //destroy  array of elements in each stack

    }
