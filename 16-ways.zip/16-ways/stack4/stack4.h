#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED
#include <iostream>
typedef int cat;
int m,n,a;
using namespace std;
class stack1{
    public:
        class rep{
            friend stack1;
            private:
                int top;
                cat *array1;
         };
typedef rep* id;
static id intialize(){
     id t=(rep*)malloc((m+1)*sizeof(rep));
     return t;
}
static void create(stack1::id s) {
    for(int i=1;i<=m;i++){
            s[i].top=0;
            s[i].array1=(cat*)malloc(n*sizeof(cat));
    }
}
static void push(stack1::id s,cat b) {
s[a].array1[s[a].top]=b;
++s[a].top;
}
static cat pop(stack1::id s) {
    cat i;
    i=s[a].array1[s[a].top];
    --s[a].top;
    return i;
}
static void print(stack1::id s){
    int i,j;
    for(i=1;i<=m;i++){ //printing of stacks and their elemnts
        cout << i<< " ";
        for(j=--s[i].top;j>=0;j--){
            cout << s[i].array1[j] << " " ;
        }
         cout  <<"\n";
    }
}
static void destroy_stack(stack1::id s){
      for(int i=1;i<=m;i++){
            delete  s[i].array1;
            if(i==m){
                delete  s; //destroy array of stack_id's
            }
      }
}
};


#endif // STACK_H_INCLUDED
