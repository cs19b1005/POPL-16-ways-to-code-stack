#ifndef REP_H_INCLUDED
#define REP_H_INCLUDED
typedef int cat;
class rep{
public:
virtual void push(int a,int b) = 0;
virtual cat pop(int a) = 0;
};


#endif // REP_H_INCLUDED
