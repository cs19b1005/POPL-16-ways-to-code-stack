#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED
#include "lstack.h"
class stack{
rep* p;
public:
void initalize(int m){
rep*p=(rep*)malloc(sizeof(rep)*m);
}
rep* get_rep() { return p; }
void put_rep(rep* q) { p= q; }
void push(int,int);
void pop(int);
/*void push(int a,int b) {
    lstack obj2;
    obj2.push(a,b);
    }
void pop(int a) {
    lstack obj3;
    obj3.pop(a); }*/
};


#endif // STACK_H_INCLUDED
