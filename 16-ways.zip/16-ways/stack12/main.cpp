#include <iostream>
#include "astack.h"
#include "lstack.h"
#include "rep.h"
#include "stack.h"
using namespace std;
int main()
{
    int i,m,n,a;
    cat b;
    cin >> m >> n;
    astack obj(n,m);
    string str; //for deciding push or pull
    for(i=0;i<n;i++){
        cin >> a >>str;
        if (str=="push"){ //to check if the operation is push
            cin >> b;
           obj.push(a,b);
        }
        else if(str=="pop"){
            obj.pop(a) ;
        }
        else{
            cout <<"Please select either push or pull";
        }
    }
  obj.convert_from_a_to_l(m);

}
