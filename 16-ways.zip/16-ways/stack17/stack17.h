#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED
#include <iostream>
typedef int cat;
using namespace std;
class stack1{
struct node{
	int data;
	struct node* link;
}**head;
public:
    stack1(int m){
     struct node* top=NULL;
     head=(node**)malloc((m+1)*sizeof(node));
    int i;
    for(i=1;i<=m;i++){
        head[i] =(node*)malloc(sizeof(node)); // allocate memory for node
        head[i]->data=i;
        head[i]->link=top;
    }
    }
    ~stack1(){
         delete head;
     }
    void push(int i,int data){
	struct node* temp;
	temp = new node;
	temp->data = data;
	temp->link = head[i]->link;
	head[i]->link= temp;
}
cat pop(int i)
{
    cat b;
    b=head[i]->link->data;
	struct node* temp;
		temp = head[i]->link;
		head[i]->link = head[i]->link->link;
		temp->link = NULL;
		free(temp);
		return b;
	}

void display(int m)
{
    int i;
	struct node* temp;
	for(i=1;i<=m;i++){
        cout <<i<<" ";
		temp = head[i]->link;
		while (temp != NULL)
		{
			cout << temp->data << " ";
			temp = temp->link;
		}
		cout<<"\n";
	}
}

};


#endif // STACK_H_INCLUDED
