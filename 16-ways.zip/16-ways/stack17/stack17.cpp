#include <iostream>
#include "stack17.h"
using namespace std;
int main()
{
    int i,m,n,a;
    cat b;
    cin >> m >> n;
    stack1 obj(m);
    string str; //for deciding push or pull
    for(i=0;i<n;i++){
        cin >> a >>str;
        if (str=="push"){ //to check if the operation is push
            cin >> b;
           obj.push(a,b);
        }
        else if(str=="pop"){
            obj.pop(a) ;
        }
        else{
            cout <<"Please select either push or pull";
        }
    }
    obj.display(m);

}
