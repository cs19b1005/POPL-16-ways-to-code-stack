#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED
#include<iostream>
int m,n,a;
using namespace std;
typedef int stack_id;
typedef int  cat;
void create_stack(stack_id**s) {
    for(int i=1;i<=m;i++){
            s[i]=new cat  [n]; //declaring a n element array for each stack
    }
}
void push_stack(stack_id ** s,int *top,cat b) {
    s[a][top[a]]=b;
    ++top[a];
}
cat pop_stack(stack_id ** s,int*top){
    cat i;
    i=s[a][top[a]];
    if(top[a]<0){
            cout <<"Error in pop";
    return 0;
    }
    --top[a];
    return i;
}
void print_stack(stack_id ** s,int*top){
    int i,j;
    for(i=1;i<=m;i++){ /*printing of stacks and their elemnts*/
            cout << i<< " ";
            for(j=top[i]-1;j>=0;j--){
                    cout << s[i][j] << " " ;
            }
            cout  <<"\n";
    }
}
void destroy_stack(stack_id **s){
    int i;
    for(i=1;i<=m;i++){
            delete [] s[i];
            if(i==m){
                    delete [] s; //destroy array of stack_id's
            }
    }
}
#endif // STACK_H_INCLUDED
