#include "stack0.h"
#include <iostream>
using namespace std;
typedef int cat;
int main()
{
    int i,j;
    cat b;
    string str; //for deciding push or pull
    cin >> m >> n;
    stack_id** s;
    int top[m+1]; //declaring an array for all the top values
    for (i=1;i<=m;i++){
        top[i]=0;
    }
    s=new stack_id*[m+1];//declaring stack id's for m stacks
    create_stack(s); //creating n elements for each stack
    for(i=0;i<n;i++){
            cin >> a >>str;
            if (str=="pop"){ //to check if the operation is push
            pop_stack(s,top);
        }
        else if(str=="push"){
                cin >> b;
                push_stack(s,top,b);
        }
    }
    print_stack(s,top);
    destroy_stack(s); //destroy  array of elements in each stack

}
