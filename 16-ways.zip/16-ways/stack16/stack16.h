#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED
#include<iostream>
using namespace std;
typedef int cat;
int m,n;
class stack1{
    int top;
    cat *array1;
public:
    stack1*s;
      void intialize(){
        s=(stack1*)malloc((m+1)*sizeof(stack1));
      }
    void create(int i){
        s[i].top=0;
        s[i].array1=(cat*)malloc(n*sizeof(cat));
    }
     void push(int a,int b) {
          s[a].array1[s[a].top]=b;
          ++s[a].top;
     }
     void pop(int a) {
          --s[a].top;
     }

    void print(){
    int i,j;
    for(i=1;i<=m;i++){ //printing of stacks and their elemnts
        cout << i<< " ";
        for(j=--s[i].top;j>=0;j--){
            cout << s[i].array1[j] << " " ;
        }
       cout  <<"\n";
    }

    }
    void destroy(){
    for(int i=1;i<=m;i++){
     delete  s[i].array1;
       if(i==m){
         delete  s; //destroy array of stack_id's
       }
    }
    }

};
#endif // STACK_H_INCLUDED
