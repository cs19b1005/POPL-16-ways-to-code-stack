#include <iostream>
#include "stack16.h"
using namespace std;
typedef int cat;
int main()
{
    int i,a;
    cat b;
    string str; //for deciding push or pull
    cin >> m >> n;
    stack1 obj;
    obj.intialize();
   for(i=1;i<=m;i++){
        obj.create(i);
   }
    for(i=0;i<n;i++){
        cin >> a >>str;
        if (str=="push"){ //to check if the operation is push
            cin >> b;
          obj.push(a,b);
        }
        else if(str=="pop"){
        obj.pop(a);
        }
        else{
            cout <<"Please select either push or pull";
        }
    }
    obj.print();
    obj.destroy();

}
