#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED
#include<iostream>
using namespace std;
typedef int cat;
int m,n,a;
class stack1{
    int top;
    cat *array1;
public:
     stack1(stack1*s){
         int i;
         for(i=1;i<=m;i++){
            s[i].top=0;
            s[i].array1=(cat*)malloc(n*sizeof(cat));}
       }
     ~stack1(){
      delete []array1;
     }
     void push(stack1*s,cat b) {
          s[a].array1[s[a].top]=b;
          ++s[a].top;
     }
     cat pop(stack1*s) {
         cat i=s[a].array1[s[a].top];
         --s[a].top;
         return i;
     }

    void print(stack1*s){
    int i,j;
    for(i=1;i<=m;i++){ //printing of stacks and their elemnts
        cout << i<< " ";
        for(j=--s[i].top;j>=0;j--){
            cout << s[i].array1[j] << " " ;
        }
       cout  <<"\n";
    }

    }
    void destroy(stack1*s){
    for(int i=1;i<=m;i++){
     delete  s[i].array1;
       if(i==m){
         delete  s; //destroy array of stack_id's
       }
    }
    }
};
#endif // STACK_H_INCLUDED
