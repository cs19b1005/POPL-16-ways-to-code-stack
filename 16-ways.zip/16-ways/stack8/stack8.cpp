#include <iostream>
#include "stack8.h"
using namespace std;
typedef int cat;
int main()
{
    int i;
    cat b;
    string str; //for deciding push or pull
    cin >> m >> n;
    stack1*s=(stack1*)malloc((m+1)*sizeof(stack1));
    stack1 obj(s);
    for(i=0;i<n;i++){
        cin >> a >>str;
        if (str=="push"){ //to check if the operation is push
            cin >> b;
          obj.push(s,b);
        }
        else if(str=="pop"){
        obj.pop(s);
        }
        else{
            cout <<"Please select either push or pull";
        }
    }
    obj.print(s);
    obj.destroy(s);

}
