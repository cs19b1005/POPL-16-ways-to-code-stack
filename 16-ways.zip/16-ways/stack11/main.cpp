#include <iostream>
#include "llstack.h"
using namespace std;
int main()
{
   int i,m,n,a;
   cin >> m >> n;
   noop xx;
   llstack* s=new(&s) llstack(xx) ;
   noop s1;
   cat b;
   llstack obj=llstack(s1);
   obj.intialize(m);
   for(i=1;i<=m;i++){
        obj.create(i,n);
   }
   string str; //for deciding push or pull
   for(i=0;i<n;i++){
        cin >> a >>str;
        if (str=="push"){ //to check if the operation is push
            cin >> b;
            obj.push(a,b);
        }
        else if(str=="pop"){
            obj.pop(a) ;
        }
        else{
            cout <<"Please select either push or pull";
        }
    }
    obj.print(m);
}
