#ifndef LLSTACK_H_INCLUDED
#define LLSTACK_H_INCLUDED
#include <iostream>
typedef int cat;
using namespace std;
class noop{};
class lstack{
    public:
        lstack(noop){}
        void push(int a,int b);
        void pop(int a);
};
class llstack: public lstack{
    struct id{
    int top;
    cat *array1;
}*s;
public:
    llstack(noop x):lstack(x){}
    void intialize(int m){
        s=(id*)malloc((m+1)*sizeof(id));
    }
    void create(int i,int n){
        s[i].top=0;
        s[i].array1=(cat*)malloc(n*sizeof(cat));
    }
    void push(int a,cat b){
        s[a].array1[s[a].top]=b;
        ++s[a].top;
    }
    cat pop(int a){
        cat i=s[a].array1[s[a].top];
        --s[a].top;
        return i;
     }
     void print(int m){
         int i,j;
         for(i=1;i<=m;i++){ //printing of stacks and their elemnts
                cout << i<< " ";
                for(j=--s[i].top;j>=0;j--){
                    cout << s[i].array1[j] << " " ;
                }
                cout  <<"\n";
        }
      }

};


#endif // LLSTACK_H_INCLUDED
