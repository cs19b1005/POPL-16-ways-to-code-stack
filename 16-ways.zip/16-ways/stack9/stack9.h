#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED
#include <iostream>
using namespace std;
typedef int cat;
class rep;
class stack1{
struct rep{
    int top;
    cat *array1;
}*p;
public:
    stack1(int m,int n){
        p=(rep*)malloc((m+1)*sizeof(rep));
        int i;
        for(i=1;i<=m;i++){
                p[i].top=0;
                p[i].array1=(cat*)malloc(n*sizeof(cat));
        }
       }
     ~stack1(){
      delete p;
     }
    void push(int a,cat b){
    p[a].array1[p[a].top]=b;
    ++p[a].top;
    }
    cat pop(int a){
    cat i=p[a].array1[p[a].top];
     --p[a].top;
     return i;
     }
    void print(int m){
    int i,j;
    for(i=1;i<=m;i++){ //printing of stacks and their elemnts
        cout << i<< " ";
        for(j=--p[i].top;j>=0;j--){
            cout << p[i].array1[j] << " " ;
        }
       cout  <<"\n";
    }
    }
};



#endif // STACK_H_INCLUDED
