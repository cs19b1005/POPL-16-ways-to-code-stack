#ifndef ASTACK_H_INCLUDED
#define ASTACK_H_INCLUDED
#include "stack.h"
typedef int cat;
class astack: public stack1{
    struct id{
    int top;
    cat *array1;
}*s;
public:
     astack(int n,int m){
         s=(id*)malloc((m+1)*sizeof(id));
         int i;
         for(i=1;i<=m;i++){
                s[i].top=0;
                s[i].array1=(cat*)malloc(n*sizeof(cat));
          }
       }
     ~astack(){
         delete s;
     }
     void push(int a,cat b){
         s[a].array1[s[a].top]=b;
         ++s[a].top;
     }
    cat pop(int a){
        cat i=s[a].array1[s[a].top];
        --s[a].top;
        return i;
     }
    void print(int m){
        int i,j;
        for(i=1;i<=m;i++){ //printing of stacks and their elements
                cout << i<< " ";
                for(j=--s[i].top;j>=0;j--){
                    cout << s[i].array1[j] << " " ;
                }
               cout  <<"\n";
        }
    }
};


#endif // ASTACK_H_INCLUDED
