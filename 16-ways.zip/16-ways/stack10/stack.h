#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED
#include <iostream>
using namespace std;
typedef int cat;
class stack1{
public:
   virtual void push(int a,cat b) = 0;
   virtual cat pop(int a)=0;

};


#endif // STACK_H_INCLUDED

