#include "stack1.h"
#include <iostream>
using namespace std;
typedef int cat;
int main()
{
    int i;
    cat b;
    cin >> m >> n;
    stack_id *s;
    s=(stack_id*)malloc((m+1)*sizeof(stack_id));
    create_stack(s);
    string str; //for deciding push or pull
    for(i=0;i<n;i++){
        cin >> a >>str;
        if (str=="push"){ //to check if the operation is push
            cin >> b;
            push_stack(s,b);
        }
        else if(str=="pop"){
            pop_stack(s);
        }
        else{
            cout <<"Please select either push or pull";
        }
    }
    print_stack(s);
    destroy_stack(s); //destroy  array of elements in each stack

}



