#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED
#include <iostream>
typedef int cat;
using namespace std;
int m,n,a;
class stack1{
   public:
   class rep{
       friend stack1;
       int top;
       cat *array1;
       rep(rep*p,int i){
           p[i].top=0;
           p[i].array1=(cat*)malloc(n*sizeof(cat));
       }
       rep(const rep&); // copy constructor
       void operator=(const rep&) ; // assignment operator
       ~rep(){
        delete [] array1;
        }
    };
    static void create(stack1:: rep*s,int i){
        stack1::rep (s,i);
    }
    static void push(stack1::rep*s,cat b) {
        s[a].array1[s[a].top]=b;
        ++s[a].top;
    }
    static cat pop(stack1::rep*s) {
        cat i;
        i=s[a].array1[s[a].top];
        --s[a].top;
        return i;
        }
    static void print(stack1::rep*s){
        int i,j;
        for(i=1;i<=m;i++){ //printing of stacks and their elements
            cout << i<< " ";
            for(j=--s[i].top;j>=0;j--){
               cout << s[i].array1[j] << " " ;
            }
            cout  <<"\n";
        }
   }
   static void cleanup(stack1::rep*s) {
       for(int i=1;i<=m;i++){
       delete  s[i].array1;
       if(i==m){
         delete  s; //destroy array of stack_id's
       }
       }
   }

};

#endif // STACK_H_INCLUDED
